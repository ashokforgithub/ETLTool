/**
 * 
 */
package com.mycomp.hack.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mycomp.hack.entity.TemplateFileDefinition;
import com.mycomp.hack.service.TemplateFDService;

/**
 * @author Ashok
 *
 */
@RestController
@RequestMapping(value="/template-manager")
public class TemplateManagerController {
	
	@Autowired
	private TemplateFDService fdService;
	
	private final Logger LOGGER = LogManager.getLogger(this.getClass());
	
	@GetMapping(path="template/{id}", produces= {MediaType.APPLICATION_JSON_VALUE} )
	public Optional<TemplateFileDefinition> fetchTemplateDetails(@Valid @PathVariable(name="id") Long id)
	{
		LOGGER.debug("Inside Template Manager Controller");
		TemplateFileDefinition templateFileDefinition =  fdService.findFDbyId(id).get();
		LOGGER.debug("record types got: ="+templateFileDefinition.getTmpltrectypes());
		templateFileDefinition.getTmpltrectypes().forEach(LOGGER::debug);
		return Optional.of(templateFileDefinition);
	}

}
